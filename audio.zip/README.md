# pacman
FUNZIONAMENTEO DEL GIOCO
Il gioco è ambientato in un labirinto composto da una serie di corridoi e stanze, dove il giocatore controlla,attraverso le frecce di direzione, un personaggio giallo a forma di disco chiamato Pac-Man. Lo scopo del gioco è quello di mangiare tutti i puntini presenti nel labirinto, evitando i "fantasmi pallina" che cercano di catturare Pac-Man.

Inoltre, ci sono anche quattro "pillole energetiche" speciali, collocate agli angoli del labirinto, che quando Pac-Man le mangia, fanno diventare i fantasmi vulnerabili per un breve periodo di tempo, rendendoli mangiabili.

l'obbiettivo del gioco è fare il maggior punteggio possibile prima di essere eliminato dai fantasmi tre volte.

COSTRUZIONE
Il sito web è suddiviso in due sezioni: una pagina di presentazione e la sezione di gioco vera e propria. La pagina di presentazione è stata creata con HTML, CSS, JavaScript e jQuery, utilizzando le competenze apprese a scuola e durante la ricerca online.

La sezione di gioco, invece, è stata realizzata utilizzando gli stessi linguaggi citati in precedenza, ma con l'aggiunta di un elemento particolare: il Canvas di HTML5. Questo strumento consente di disegnare grafici, forme e immagini all'interno della pagina web, rendendo il gioco ancora più coinvolgente e interattivo.

WHO ARE WE?
Siamo due studenti dell' istituto Blaise Pascal di Reggio Emilia, se ci volete contattare su istagram ci chiamiamo rispettivamente: @alleiori_ , @whatisloveGal